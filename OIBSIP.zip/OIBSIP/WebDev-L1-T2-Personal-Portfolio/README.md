# Sagar Relekar — Personal Portfolio

Responsive personal portfolio made with HTML5 and CSS3. No JavaScript is required.

## Files
- `index.html` — portfolio content and sections
- `style.css` — responsive layout and visual design

## Run locally
1. Extract this ZIP.
2. Open the folder in VS Code.
3. Open `index.html` in a browser, or use the Live Server extension.

## Before publishing
- Replace `sagar.relekar@example.com` with your real professional email.
- Replace the generic GitHub and LinkedIn links with your actual profile/repository URLs.
- Add a professional photo if you want one; the current hero uses a CSS code-window illustration.
- Check that all project descriptions accurately reflect your work.
- Google Fonts requires internet access; fallback fonts are available.
