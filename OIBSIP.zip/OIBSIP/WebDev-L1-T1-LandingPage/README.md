# NovaTech Landing Page

A responsive static landing page built with HTML5 and CSS3 only.

## Files
- `index.html` — page structure and content
- `style.css` — layout, colors, responsive styles, and decorative visuals

## Run it
1. Extract the ZIP file.
2. Keep `index.html` and `style.css` in the same folder.
3. Open `index.html` in a browser.

No JavaScript or build tools are required. The Google Fonts connection needs internet access; system sans-serif fallbacks are available.

## Customize
- Change brand text and page copy in `index.html`.
- Change the color variables near the top of `style.css`.
- Update placeholder email, phone, and social links in the footer.
