const form = document.getElementById("converterForm");
const temperatureInput = document.getElementById("temperature");
const unitSelect = document.getElementById("unit");
const errorMessage = document.getElementById("errorMessage");
const results = document.getElementById("results");

const celsiusResult = document.getElementById("celsiusResult");
const fahrenheitResult = document.getElementById("fahrenheitResult");
const kelvinResult = document.getElementById("kelvinResult");

const ABSOLUTE_ZERO_C = -273.15;
const ABSOLUTE_ZERO_F = -459.67;

function formatTemperature(value) {
  if (Object.is(value, -0)) {
    value = 0;
  }

  return Number(value.toFixed(4)).toLocaleString("en-US", {
    maximumFractionDigits: 4,
    useGrouping: false,
  });
}

function showError(message) {
  errorMessage.textContent = message;
  results.hidden = true;
}

form.addEventListener("submit", function (event) {
  event.preventDefault();

  errorMessage.textContent = "";

  const rawValue = temperatureInput.value.trim();
  const temperature = Number(rawValue);
  const unit = unitSelect.value;

  if (rawValue === "" || !Number.isFinite(temperature)) {
    showError("Please enter a valid numeric temperature.");
    temperatureInput.focus();
    return;
  }

  if (unit === "C" && temperature < ABSOLUTE_ZERO_C) {
    showError("Celsius cannot be below −273.15°C (absolute zero).");
    temperatureInput.focus();
    return;
  }

  if (unit === "F" && temperature < ABSOLUTE_ZERO_F) {
    showError("Fahrenheit cannot be below −459.67°F (absolute zero).");
    temperatureInput.focus();
    return;
  }

  if (unit === "K" && temperature < 0) {
    showError("Kelvin cannot be below 0 K (absolute zero).");
    temperatureInput.focus();
    return;
  }

  let celsius;

  if (unit === "C") {
    celsius = temperature;
  } else if (unit === "F") {
    celsius = ((temperature - 32) * 5) / 9;
  } else {
    celsius = temperature - 273.15;
  }

  const fahrenheit = (celsius * 9) / 5 + 32;
  const kelvin = celsius + 273.15;

  celsiusResult.textContent = `${formatTemperature(celsius)} °C`;
  fahrenheitResult.textContent = `${formatTemperature(fahrenheit)} °F`;
  kelvinResult.textContent = `${formatTemperature(kelvin)} K`;

  results.hidden = false;
});
